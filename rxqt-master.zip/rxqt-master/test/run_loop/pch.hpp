#pragma once

#include <QtTest/QtTest>
#include <rxqt.hpp>
